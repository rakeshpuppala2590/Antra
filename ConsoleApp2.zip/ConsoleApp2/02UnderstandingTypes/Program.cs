﻿// See https://aka.ms/new-console-template for more information
/* 
Console.WriteLine("Hacker Name Generator");
Console.WriteLine("Enter Favourite Color:");
string favouriteColor = Console.ReadLine() ?? "Red";;
Console.WriteLine("Enter your astrology Sign");
string astrologySign = Console.ReadLine() ?? "Libra";;
Console.WriteLine("Enter your street address number");
int streetAddress = int.Parse(Console.ReadLine() ?? "3100");
string hackerName = favouriteColor+astrologySign+streetAddress;
Console.WriteLine($"Hacker name: {hackerName}"); 
 */

using System;

namespace _02UnderstandingTypes
{
    class Program
    {
        public static void Main()
        {
            Console.WriteLine("{0,-15} {1,-10} {2,-35} {3,-25}", "Type", "Bytes", "Min Value", "Max Value");
            Console.WriteLine(new string('-', 100));

            DisplayTypeInfo("sbyte", sizeof(sbyte), sbyte.MinValue, sbyte.MaxValue);
            DisplayTypeInfo("byte", sizeof(byte), byte.MinValue, byte.MaxValue);
            DisplayTypeInfo("short", sizeof(short), short.MinValue, short.MaxValue);
            DisplayTypeInfo("ushort", sizeof(ushort), ushort.MinValue, ushort.MaxValue);
            DisplayTypeInfo("int", sizeof(int), int.MinValue, int.MaxValue);
            DisplayTypeInfo("uint", sizeof(uint), uint.MinValue, uint.MaxValue);
            DisplayTypeInfo("long", sizeof(long), long.MinValue, long.MaxValue);
            DisplayTypeInfo("ulong", sizeof(ulong), ulong.MinValue, ulong.MaxValue);
            DisplayTypeInfo("float", sizeof(float), float.MinValue, float.MaxValue);
            DisplayTypeInfo("double", sizeof(double), double.MinValue, double.MaxValue);
            DisplayTypeInfo("decimal", sizeof(decimal), decimal.MinValue, decimal.MaxValue);
            
            Convert();
            FizzBuzz();
            
            guess();
            pyramid();
            check();
            rest_of_questions();
        }

        public static void DisplayTypeInfo(string typeName, int byteSize, IConvertible minValue, IConvertible maxValue)
        {
            Console.WriteLine("{0,-15} | {1,-9} | {2,-33} | {3,-25}", 
                typeName, byteSize, minValue.ToString(), maxValue.ToString());
        }
        
        public static void Convert()
        {
            Console.Write("Enter number of centuries: ");
            long centuries = long.Parse(Console.ReadLine() ?? "1");
            decimal years = centuries * 100m;
            decimal days = centuries * 36524m;
            decimal hours = days * 24m;
            decimal minutes = hours * 60m;
            decimal seconds = minutes * 60m;
            decimal milliseconds = seconds * 1000m;
            decimal microseconds = milliseconds * 1000m;
            decimal nanoseconds = microseconds * 1000m;

            Console.WriteLine($"{centuries} century(s) is equivalent to:");
            Console.WriteLine($"{years} years");
            Console.WriteLine($"{days:N0} days");
            Console.WriteLine($"{hours:N0} hours");
            Console.WriteLine($"{minutes:N0} minutes");
            Console.WriteLine($"{seconds:N0} seconds");
            Console.WriteLine($"{milliseconds:N0} milliseconds");
            Console.WriteLine($"{microseconds:N0} microseconds");
            Console.WriteLine($"{nanoseconds:N0} nanoseconds");
        }

        public static void FizzBuzz()
        {
            for (int i = 1; i <= 100; i++)
            {
                if (i % 3 == 0 && i % 5 == 0)
                {
                    Console.WriteLine("FizzBuzz");
                }
                else if (i % 3 == 0)
                {
                    Console.WriteLine("Fizz");
                }
                else if (i % 5 == 0)
                {
                    Console.WriteLine("Buzz");
                }
                else
                {
                    Console.WriteLine(i);
                }
            }
        }

        public static void guess()
        {
            int correctNumber = new Random().Next(1, 4);  
            Console.Write("Guess a number between 1 and 3: ");
        
            int guessedNumber = int.Parse(Console.ReadLine() ?? "");

            if (guessedNumber < 1 || guessedNumber > 3)
            {
                Console.WriteLine("Your guess is out of range! Please enter a number between 1 and 3");
            }
            else if (guessedNumber < correctNumber)
            {
                Console.WriteLine("Too low! Try again");
            }
            else if (guessedNumber > correctNumber)
            {
                Console.WriteLine("Too high! Try again");
            }
            else
            {
                Console.WriteLine("Correct! You guessed the number");
            }
        }

        public static void pyramid()
        {
            Console.Write("Enter the number of rows: ");
            int rows = int.Parse(Console.ReadLine() ?? "0");

            for (int i = 1; i <= rows; i++)
            {
                for (int j = 1; j <= rows - i; j++)
                {
                    Console.Write(" ");
                }

                for (int k = 1; k <= (2 * i - 1); k++)
                {
                    Console.Write("*");
                }

                Console.WriteLine(); 
            }
        }
        public static void check()
        {
            int correctNumber = new Random().Next(1, 4);
            Console.Write("Guess a number between 1 and 3: ");
            int guessedNumber = int.Parse(Console.ReadLine());

            if (guessedNumber < 1 || guessedNumber > 3)
                Console.WriteLine("Out of range! Guess between 1 and 3");
            else if (guessedNumber < correctNumber)
                Console.WriteLine("Too low!");
            else if (guessedNumber > correctNumber)
                Console.WriteLine("Too high!");
            else
                Console.WriteLine("Correct!");
        }


        public static void rest_of_questions()
        {
            DateTime birthDate = new DateTime(1995, 5, 15);
            int daysOld = (DateTime.Now - birthDate).Days;
            int daysToNextAnniversary = 10000 - (daysOld % 10000);
            DateTime nextAnniversary = DateTime.Now.AddDays(daysToNextAnniversary);
            Console.WriteLine($"You are {daysOld} days old.");
            Console.WriteLine($"Your next 10,000-day anniversary is on {nextAnniversary:MMMM dd, yyyy}.");

            int hour = DateTime.Now.Hour;
            if (hour >= 5 && hour < 12) Console.WriteLine("Good Morning");
            if (hour >= 12 && hour < 17) Console.WriteLine("Good Afternoon");
            if (hour >= 17 && hour < 21) Console.WriteLine("Good Evening");
            if (hour >= 21 || hour < 5) Console.WriteLine("Good Night");

            for (int i = 1; i <= 4; i++)
            {
                for (int j = 0; j <= 24; j += i)
                {
                    Console.Write(j);
                    if (j + i <= 24) Console.Write(",");
                }
                Console.WriteLine();
            }
        }
    }
}

